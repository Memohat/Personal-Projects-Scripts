# Make-new-python-script
Makes a new python script and a batch file for it, so it can be run from terminal
