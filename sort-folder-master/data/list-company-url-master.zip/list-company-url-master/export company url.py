#!python3
# Mehmet Hatip
"""
Program functions to get company names from the specified file in the directory,
get the html page of a google search for each of the companies, and return the
first result on google of each search in a new csv file, that also has the
company name in the next column.
"""


import os, csv, requests, bs4, time
"""
Very important modules, os lets you change directory so the file can be
accessed from another folder. csv is a module for writing and reading csv
files. requests gets an html page from the internet using a URL. bs4, or
beautifulsoup4, makes the request txt into an easily searchable and usable
format, one in which finding the right URL is no problem. Time is for 
delaying the program so it doesn't request too much at once.
"""

path = os.getcwd()
# path of company names file

name = "Company + URL" 
# name of company names file

os.chdir(path)
# changing directory

company_url = []
# list will store tuples in the form of (company name, google search url)

flags = ['wikipedia', 'bloomberg', 'linkedin', 'google']

def valid_url(url, flags):
    valid = True
    for flag in flags:
        valid = url.find(flag) == -1
        if not valid:
            return False
    return True
with open("source.txt", encoding="utf-16") as fin:
    # opening company names file

    #fin.readline()
    # skipping header

    try:
        for company in fin:
            company = company.replace('"', '').strip()
            if not company == '':
                company_url.append((company, "https://www.google.com/search?q="
                                    + company.replace(' ', '+')))
        # for every company listed on the file, add the name and the google search
        # url to the list.
    except UnicodeDecodeError as error:
        print(f"\nOne of the company names could not be read properly.")
        if input("Press e for error message: ") == 'e':
            print(error)
        exit()
    # try statement catches company names that have weird symbols, prints out
    # in console, and exits program

with open(f"{name}.csv", 'a+', newline='') as fout:
    # opening output file
    
    writer = csv.writer(fout)
    # using csv module
    
    i = 0
    # counter for number of companies done
    
    writer.writerow(['Company', 'Website', 'Invalid?'])

    invalid = ''

    for company, google_url in company_url:
        # using the complete list from above

        request = requests.get(google_url)
        # get html file with google url with requests

        request.raise_for_status()
        # make sure file was successfully obtained
        
        soup = bs4.BeautifulSoup(request.text, features='html.parser')
        # make new BeautifulSoup object using request.text
                     
        info = soup.select('.r a')[0]
        """
        specification to get the first search result on google using bs4.
        in '.r a', .r specifies to look for the class attribute r, while
        a specifies to look for the element named a. This is where all the
        searches are stored, so getting the first element off of the list
        produced by this would require the [0] at the end.
        """
            
        url = info.get('href')
        # url is stored in 'href' attribute. We get the url using get
        
        valid = valid_url(url, flags)

        j = 0

        while not valid:
            j += 1

            info = soup.select('.r a')[j]

            url = info.get('href')

            valid = valid_url(url, flags)
            
            invalid = 'x'

        start_index = str.find(url, 'http')
        # we define start index of url to be where http is in the string.
                
        domain_index = str.find(url, '//') + 2
        """
        all urls have a // before the domain name begins.
        this index finds the // and adds two to get the index of the string
        where the domain starts
        """
        
        end_index = str.find(url[domain_index:], '/') + domain_index
        """
        the index of the first /, which is where the base website ends after 
        .com or .org or whatever. We add domain and / index to get
        the end index of the part of the url we are interested in.
        """
        
        url = url[start_index:end_index]
        # very simple, change url so that it is from the start to end index.

        writer.writerow([company, url, invalid])
        # write the company name and its url into the output file.
        
        i += 1
        # add 1 to the counter

        print(f"{i} {company}")
        #print the counter and company name on the console

        time.sleep(20)
        # delaying for 30 seconds so program is not requesting too much at once
        

print(f"File stored in {path}")
# end message saying file was stored


    