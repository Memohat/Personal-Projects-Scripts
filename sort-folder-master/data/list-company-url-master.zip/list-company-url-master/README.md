# list-company-url

The program takes a list of company names as a .csv or .txt file, and exports a list of the websites for the companies in a new file.

Company + URL v3 final.csv is the file that contains each company name with the URL, if there is no valid URL, the space is left blank, some of them may redirect to wiki or 3rd party information websites so that should be considered.

CompanyList.xlsx is the file containing company names

source.txt is the above file converted to text format for the program to read

export company url.py is the program file
