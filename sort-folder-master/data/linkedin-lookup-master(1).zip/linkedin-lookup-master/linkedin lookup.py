#!python3
# Mehmet Hatip

import webbrowser, os

name = "linkedin lookups.csv"
skip = False

with open(name) as fin:

	for line in fin:
		if not skip:
			company = line
			print(company)
			linkedinURL = ("https://www.linkedin.com/search/results/companies/?keywords="
							+ company.replace('&','%26') + "&origin=SWITCH_SEARCH_VERTICAL")
			webbrowser.open(linkedinURL)
			answer = input("Press enter to continue to next company, s to skip next, e to exit: ")
			if answer == 's':
				skip = True
			elif answer == 'e':
				exit()
		else:
			skip = not skip