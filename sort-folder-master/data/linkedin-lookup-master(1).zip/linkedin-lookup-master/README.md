# linkedin-lookup
looking up linkedin accounts for companies
